注意:如果你正在使用Yubideck(大四)或者TASOLLER/Brokenithm
请不要从群内下载其他版本的io覆盖至游戏
请不要从群内下载其他版本的io覆盖至游戏
请不要从群内下载其他版本的io覆盖至游戏
本工具自带所有io更新
从工具的老版本升级 请务必直接除了segatools.ini以外全部覆盖

如果你曾使用其他类型的segatools(例如需要分开chusanio_x86或者chusanio_x64的segatools)
请下载一个干净的好弟弟覆盖本工具 不要用乱七八糟的文件跑

1.0.3.4 更新:
此次更新为临时版本，主要是为支持 TASOLLER PLUS 出货，让玩家尽快体验新功能。后续将在修复 TASOLLER IO 问题后发布正式更新。

修复内容

	1.	修复了 lmn 开始的 VFS 问题。
	2.	在 start.bat 中新增以下功能：
	•	挂载 duolinguo.dll 的逻辑；
	•	自动以管理员权限启动；
	•	修复 OpenSSL 问题。
	3.	Hook功能 调整：强制设备窗口化时不再按系统 DPI 设置缩放游戏画面。

新增功能

	1.	支持 TASOLLER PLUS。
	2.	支持 Stavona IO：兼容 Stavona R 和其他基于 Stavona协议 的控制器。

免责声明

Stavona IO由 StarriHX/Stavona-chuniio 提供维护和支持。
fufubot team 仅集成该DLL以方便玩家使用。需要注意的是，该DLL具有通过GitHub API自动更新的功能。
fufubot team不对该DLL的安全性及其他相关内容负责，如需帮助，请直接联系开发者。

错误反馈

若需报告任何问题（Stavona IO相关问题除外），请通过以下方式联系：
	1.	在对应的玩家交流群中寻找我。
	2.	通过邮件联系 segatools@fufubot.com。

    请注意：邮件内容仅支持中文、英文、日语或粤语，其他语言的邮件将不予回复。此外，我们保留对邮件进行筛选并决定是否回复的权利。
    Please note: Only emails in Chinese, English, Japanese, or Cantonese will be considered. Emails in other languages will not receive a response. Additionally, we reserve the right to decide whether or not to reply to any email.
    ご注意ください：メール内容は中国語、英語、日本語、または広東語のみ対応可能です。それ以外の言語のメールには返信いたしません。また、弊チームは全てのメールに返信する義務がないことをご了承ください。
    請留意：電郵內容僅支援中文、英文、日文或粵語，其他語言的電郵將不獲回覆。另外，我們保留篩選及決定是否回覆電郵的權利。

1.0.3.3 更新: 
实验版本 曾增加了如果未检测到C:/drama.lock则打开README.txt并退出程序的功能 目前去掉了未检测到drama.lock强制打开README.txt的逻辑 
由于一些内部逻辑有问题 当时未正式发布

1.0.3.2 更新:
给YubiDeck增加了一个新的配置选项 led_output
如果led_output为0 则手台的所有灯效均不会由游戏接管 任何情况手台灯效均会使用手台自带的灯效

1.0.3.1 更新:
YubiDeck的side_random 设置为2后 左右侧抬手时随机的颜色为相同颜色 1为不同颜色

1.0.3 更新:
1:修改了TASOLLER io的文案细节 以及Zhousensor io的文案细节
现在TASOLLER以及YubiDeck 均会在手台插拔后在控制台显示插拔状态
同时 支持了在控制台显示目前插入的手台是高三还是大四 是新固件还是旧固件
2:由于上次更新大改了usb协议 暂时移除了旧版大四固件和高三的支持 本次更新后已加回
3:由于大量用户搞不清楚怎么修改json 本次更新携带了一个外挂的json 将启动脚本覆盖 并将所有原本的json还原为原装json
即可直接使用 无需调整正常需要调整的auth2 和emoney关闭 以及accouting之类的玩意儿 
移除start.bat内config_hook.json的挂载即可直接去掉这份修改
4:现在切换120和60模式无需填写led端口号 配置文件内的相关条目可以直接移除
5:如果dipsw2和dipsw3填写了不同的值 或乱填 游戏会直接退出 这不是一个bug 请认真填写


1.0.2 更新:
大改了周台的usb协议格式 本次更换chuniio需要同时刷新固件 固件会另外提供
同时增加了以下功能:
1:将real_led设置为0时 可以像以前一样抬手亮灯 侧灯不会被游戏接管
2:将side_random设置为1时 每次抬手会显示不同的颜色 (仅限real_led为0时)
3:游戏可以单独控制大四左侧和右侧的LED灯(上一个版本是仅传输左侧led灯的信号 两边同时显示)
4:灯光亮度精细化
5:关闭游戏后 大四会回到刚启动大四时的状态下

注:如果你是高三/源2用户 目前chuniio-mux.dll已被修改为仅支持大四dll的聚合 如果需要使用高三/源2的用户
请手动将dll指向chuniio_zhou.dll(老版本dll)

新版本io文件为yubideck.dll

同时 tasoller_chuniio.dll已被修改为tasoller.dll 以规范命名格式 原有的dll将会被弃用



因为segatools.ini里的英文注释已经非常明显了
我就挑几个重点说

这个版本与最近公开的版本区别在于增加了LED的功能 并且准备了大多数玩家应该都不用配置io的懒人包

segatools.ini内默认挂载的是chuniio-mux.dll 这个是一个聚合的dll 会同时挂载这份懒人包内针对周台 dao台 以及brokenithm使用的dll

如果你要使用这个dll 请不要修改这些dll的名字 如果想挂自己的dll 请直接取名chuniio.dll 让他挂chuniio.dll就行

如果你的游戏以cvt模式运行 请修改DIPSW内的dipsw2和dipsw3 为0 

我们不保证此工具可以支持除了SDHD以外的任何游戏

使用大四的用户 如果使用的是大四自带的读卡器刷控制器自带的卡/旧制式的卡(aime) 在使用此dll后会使用卡背后的真实卡号刷卡
如果想关闭此功能 请将real_aime调为0

由于这份dll并不是zhousensor官方意义上发布的工具 有问题找周老板也没用

这份chuniio_zhou.dll同时支持大四 高三 以及源2

郑重声明:
我们不对此dll/工具的性能/延迟/可用性以及任何的东西做任何保证
如果你觉得这个游戏很好玩 中二节奏中国版已经上市 请务必在可以支持的情况下去机厅支持华立的中二节奏
fufubot team举双手双脚支持华立代理舞萌DX以及中二节奏

严禁使用此工具跳脸华立/世嘉

此工具的仅供学习用途 请务必在下载的24小时内删除所有的副本

Hello Evil Chinese Leaker i am your good friend leak me national battle don't using fufubot segetools it is broken